# PowerShell 5.1. Owner-only GET response size measurement.
# Cursor does not run this on Production. No APPLY. No POST.
# Sends pregenerated owner_measure_stdin.py byte-for-byte on SSH stdin.
# Does not concatenate Python files. No SCP. No remote mkdir. No sudo.
# Wrapper never sets OWNER_PRODUCTION_022_MEASURE_APPROVED.
$ErrorActionPreference = 'Continue'
$Key = 'C:\Users\Mr.me\Downloads\expect-beta-tokyo.pem'
$Target = 'ubuntu@13.231.5.5'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$StdinPy = Join-Path $Here 'owner_measure_stdin.py'
$Downloads = Join-Path $env:USERPROFILE 'Downloads'
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$OutLog = Join-Path $Downloads ('production_022_readonly_response_size_measure_v2_20260911_output_' + $Stamp + '.txt')
$TimeoutMs = 180000
$script:KillDrainWaitMs = 8000
$script:DrainWaitMs = 20000

if (Test-Path -LiteralPath $OutLog) {
    Write-Output 'OWNER_MEASURE_STATUS=FAIL'
    Write-Output 'ERROR=refuse_overwrite_existing_output'
    Write-Output ('OUTPUT=' + $OutLog)
    exit 1
}

function Stop-ProcessTree {
    param([int]$ProcessId)
    if ($ProcessId -le 0) { return }
    $tk = $null
    try { $tk = Get-Command 'taskkill.exe' -ErrorAction SilentlyContinue } catch { $tk = $null }
    if ($null -ne $tk) {
        try { & taskkill.exe /PID $ProcessId /T /F | Out-Null } catch { }
        return
    }
    try {
        $p = [System.Diagnostics.Process]::GetProcessById($ProcessId)
        if ($null -ne $p) {
            if (-not $p.HasExited) { $p.Kill() }
        }
    } catch { }
}

function Get-TaskText {
    param($Task, [string]$Name)
    if ($null -eq $Task) { return ('(%s drain not started)' -f $Name) }
    $ran = [System.Threading.Tasks.TaskStatus]::RanToCompletion
    if ($Task.Status -eq $ran) {
        try { return [string]$Task.Result } catch { return ('(%s result error)' -f $Name) }
    }
    if ($Task.IsFaulted) {
        return ('(%s drain faulted status=%s)' -f $Name, [string]$Task.Status)
    }
    return ('(%s drain incomplete status=%s)' -f $Name, [string]$Task.Status)
}

function Get-RemoteMeasureState {
    param([string]$StdOut)
    $status = 'UNKNOWN'
    $oversized = 'UNKNOWN'
    if (-not [string]::IsNullOrEmpty($StdOut)) {
        $lines = $StdOut -split "(`r`n|`n)"
        foreach ($ln in $lines) {
            if ($ln.StartsWith('OWNER_MEASURE_STATUS=')) {
                $status = $ln.Substring(21)
            }
            if ($ln.StartsWith('HTTP_BODY_OVERSIZED=')) {
                $oversized = $ln.Substring(20)
            }
        }
    }
    return @{
        MeasureStatus = $status
        BodyOversized = $oversized
    }
}

function Get-WrapperAuditStatus {
    param(
        [bool]$TimedOut,
        [string]$ExitCodeText
    )
    if ($TimedOut) {
        return @{
            Status = 'FAILED'
            Reason = 'TIMEOUT'
            WrapperExit = 1
            SshExit = $ExitCodeText
        }
    }
    if ($ExitCodeText -ne '0' -and $ExitCodeText -ne '3') {
        return @{
            Status = 'FAILED'
            Reason = 'SSH_EXIT'
            WrapperExit = 1
            SshExit = $ExitCodeText
        }
    }
    return @{
        Status = 'SUCCESS'
        Reason = 'OK'
        WrapperExit = [int]$ExitCodeText
        SshExit = $ExitCodeText
    }
}

function Test-OwnerApprovalReady {
    param([string]$Approved)
    if ($Approved -ne '1') {
        return @{
            Ready = $false
            Reason = 'OWNER_PRODUCTION_022_MEASURE_APPROVED_UNSET'
        }
    }
    return @{
        Ready = $true
        Reason = 'OK'
    }
}

function Get-Sha256Hex {
    param([byte[]]$Bytes)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hash = $sha.ComputeHash($Bytes)
    } finally {
        $sha.Dispose()
    }
    return (([System.BitConverter]::ToString($hash) -replace '-', '').ToLowerInvariant())
}

function Invoke-TimedProcess {
    param(
        [string]$FileName,
        [string]$Arguments,
        [int]$TimeoutMs,
        [string]$StdinText,
        [byte[]]$StdinBytes
    )
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $FileName
    $psi.Arguments = $Arguments
    $psi.UseShellExecute = $false
    $psi.RedirectStandardInput = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $proc = New-Object System.Diagnostics.Process
    $proc.StartInfo = $psi
    $started = $false
    $stdoutTask = $null
    $stderrTask = $null
    try {
        [void]$proc.Start()
        $started = $true
        $stdoutTask = $proc.StandardOutput.ReadToEndAsync()
        $stderrTask = $proc.StandardError.ReadToEndAsync()
        if ($null -ne $StdinBytes) {
            $proc.StandardInput.BaseStream.Write($StdinBytes, 0, $StdinBytes.Length)
            $proc.StandardInput.BaseStream.Flush()
            $proc.StandardInput.Close()
        } elseif ($null -ne $StdinText) {
            $utf8NoBom = New-Object System.Text.UTF8Encoding $false
            $w = New-Object System.IO.StreamWriter($proc.StandardInput.BaseStream, $utf8NoBom)
            $w.NewLine = "`n"
            $w.Write($StdinText)
            $w.Flush()
            $w.Close()
        } else {
            $proc.StandardInput.Close()
        }
        $exited = $proc.WaitForExit($TimeoutMs)
        if (-not $exited) {
            Stop-ProcessTree -ProcessId $proc.Id
            try { [void]$stdoutTask.Wait($script:KillDrainWaitMs) } catch { }
            try { [void]$stderrTask.Wait($script:KillDrainWaitMs) } catch { }
            try { [void]$proc.WaitForExit($script:KillDrainWaitMs) } catch { }
            $exitText = 'STILL_RUNNING'
            try {
                if ($proc.HasExited) { $exitText = [string]$proc.ExitCode }
            } catch { }
            return @{
                TimedOut = $true
                ExitCode = -1
                ExitCodeText = $exitText
                StdOut = (Get-TaskText -Task $stdoutTask -Name 'stdout')
                StdErr = (Get-TaskText -Task $stderrTask -Name 'stderr')
                DrainStarted = $true
            }
        }
        try { [void]$stdoutTask.Wait($script:DrainWaitMs) } catch { }
        try { [void]$stderrTask.Wait($script:DrainWaitMs) } catch { }
        $code = -1
        try { $code = $proc.ExitCode } catch { }
        return @{
            TimedOut = $false
            ExitCode = $code
            ExitCodeText = [string]$code
            StdOut = (Get-TaskText -Task $stdoutTask -Name 'stdout')
            StdErr = (Get-TaskText -Task $stderrTask -Name 'stderr')
            DrainStarted = $true
        }
    } catch {
        if ($started) {
            try { Stop-ProcessTree -ProcessId $proc.Id } catch { }
            try { if ($null -ne $stdoutTask) { [void]$stdoutTask.Wait(2000) } } catch { }
            try { if ($null -ne $stderrTask) { [void]$stderrTask.Wait(2000) } } catch { }
        }
        return @{
            TimedOut = $false
            ExitCode = -1
            ExitCodeText = 'START_ERROR'
            StdOut = (Get-TaskText -Task $stdoutTask -Name 'stdout')
            StdErr = ((Get-TaskText -Task $stderrTask -Name 'stderr') + [Environment]::NewLine + [string]$_.Exception.Message)
            DrainStarted = ($null -ne $stdoutTask)
        }
    }
}

function Write-Log([string]$Line) {
    Add-Content -LiteralPath $OutLog -Value $Line -Encoding UTF8
}

function Write-AuditBlock([string]$Title, [string]$Body) {
    Write-Log ('----- ' + $Title + ' -----')
    if ([string]::IsNullOrEmpty($Body)) {
        Write-Log '(empty)'
        return
    }
    $lines = $Body -split "(`r`n|`n)"
    foreach ($ln in $lines) {
        if ($ln -match '^(AWS_|SECRET|TOKEN|PASSWORD|API_KEY|EXPECT_AI_API|X-AI-Key)') {
            Write-Log 'REDACTED_SECRET_LINE'
            continue
        }
        if ($ln -match '^[A-Za-z0-9+/]{80,}={0,2}$') {
            Write-Log 'REDACTED_BASE64_LINE'
            continue
        }
        Write-Log $ln
    }
}

function Get-SshOptString([string]$Pem) {
    return ('-i "' + $Pem + '" -o BatchMode=yes -o ConnectTimeout=15 -o ConnectionAttempts=3 -o ServerAliveInterval=5 -o ServerAliveCountMax=3')
}

Set-Content -LiteralPath $OutLog -Value 'PRODUCTION_022_READONLY_RESPONSE_SIZE_MEASURE_V2_20260911' -Encoding UTF8
Write-Log ('STARTED=' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'))
Write-Log 'WRAPPER_VERSION=owner_measure_022_v2_20260911'
Write-Log 'MEASURE_ONLY=YES'
Write-Log 'APPLY_IN_THIS_PACK=NO'
Write-Log 'V4_RERUN=NO'
Write-Log 'V1_MEASURE_ZIP_OVERWRITE=NO'
Write-Log 'V4_APPLY_ZIP_OVERWRITE=NO'
Write-Log 'V3_APPLY_ZIP_OVERWRITE=NO'
Write-Log 'V2_APPLY_ZIP_OVERWRITE=NO'
Write-Log 'V1_APPLY_ZIP_OVERWRITE=NO'
Write-Log 'REMOTE_HARD_DEADLINE_S=90'
Write-Log 'WRAPPER_TIMEOUT_MS=180000'
Write-Log 'POST_ENABLE_IN_THIS_PACK=NO'
Write-Log 'SITE_SWITCH_IN_THIS_PACK=NO'
Write-Log 'SSH_STARTED=NO'
Write-Log 'SCP_USED=NO'
Write-Log 'REMOTE_MKDIR_FROM_WRAPPER=NO'
Write-Log 'SUDO_INVOKED=NO'
Write-Log 'PERSISTENT_ENV_CHANGED=NO'
Write-Log 'PRODUCTION_APPLY_READY=NO'
Write-Log 'OWNER_APPLY_APPROVED=NO'
Write-Log 'WRAPPER_SETS_OWNER_PRODUCTION_022_MEASURE_APPROVED=NO'
Write-Log 'WINDOWS_ENV_IS_NOT_PRODUCTION_EVIDENCE=YES'
Write-Log ('OUTPUT=' + $OutLog)

$approvedText = [string]$env:OWNER_PRODUCTION_022_MEASURE_APPROVED
$gate = Test-OwnerApprovalReady -Approved $approvedText
Write-Log ('APPROVAL_READY=' + $(if ($gate.Ready) { 'YES' } else { 'NO' }))
Write-Log ('APPROVAL_GATE_REASON=' + [string]$gate.Reason)
if (-not $gate.Ready) {
    Write-Log 'SSH_STARTED=NO'
    Write-Log ('HALT_REASON=' + [string]$gate.Reason)
    Write-Log 'OWNER_MEASURE_STATUS=FAIL'
    Write-Log 'APPLY_EXECUTED=NO'
    Write-Log 'PRODUCTION_APPLY_READY=NO'
    Write-Log ('FINISHED=' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'))
    Write-Output 'OWNER_MEASURE_STATUS=FAIL'
    Write-Output ('HALT_REASON=' + [string]$gate.Reason)
    Write-Output 'SSH_STARTED=NO'
    Write-Output ('OUTPUT=' + $OutLog)
    exit 2
}

if (-not (Test-Path -LiteralPath $StdinPy)) {
    Write-Log 'HALT_REASON=STDIN_PY_MISSING_ON_WINDOWS_PACK'
    Write-Output 'OWNER_MEASURE_STATUS=FAIL'
    Write-Output 'HALT_REASON=STDIN_PY_MISSING_ON_WINDOWS_PACK'
    Write-Output ('OUTPUT=' + $OutLog)
    exit 2
}

$StdinBytes = [System.IO.File]::ReadAllBytes($StdinPy)
$payloadSha = Get-Sha256Hex -Bytes $StdinBytes
Write-Log ('STDIN_PAYLOAD_SHA256=' + $payloadSha)
Write-Log 'STDIN_CONCATENATED_AT_RUNTIME=NO'
Write-Log 'STDIN_SOURCE=owner_measure_stdin.py'
$remoteCmd = 'OWNER_PRODUCTION_022_MEASURE_APPROVED=1 PYTHONDONTWRITEBYTECODE=1 python3 -'
$sshOpt = Get-SshOptString $Key
$remoteArgs = $sshOpt + ' ' + $Target + ' ' + $remoteCmd
Write-Log 'SSH_STARTED=YES'
Write-Log 'STDIN_PYTHON=YES'
Write-Log 'REMOTE_COMMAND=python3 -'
$remote = Invoke-TimedProcess -FileName 'ssh' -Arguments $remoteArgs -TimeoutMs $TimeoutMs -StdinBytes $StdinBytes
Write-Log ('SSH_TIMEOUT=' + $(if ($remote.TimedOut) { 'YES' } else { 'NO' }))
Write-Log ('SSH_EXIT_RAW=' + $remote.ExitCodeText)
Write-AuditBlock 'REMOTE_STDOUT' $remote.StdOut
if ($remote.StdErr) { Write-AuditBlock 'REMOTE_STDERR' $remote.StdErr }

$remoteState = Get-RemoteMeasureState -StdOut ([string]$remote.StdOut)
Write-Log ('REMOTE_MEASURE_STATUS=' + [string]$remoteState.MeasureStatus)
Write-Log ('REMOTE_HTTP_BODY_OVERSIZED=' + [string]$remoteState.BodyOversized)
$st = Get-WrapperAuditStatus -TimedOut $remote.TimedOut -ExitCodeText $remote.ExitCodeText
if ($remote.TimedOut) {
    Write-Log 'PARTIAL_STDOUT_SAVED=YES'
    Write-Log 'PARTIAL_STDERR_SAVED=YES'
}
Write-Log ('AUDIT_STATUS=' + $st.Status)
Write-Log ('SSH_EXIT=' + $st.SshExit)
Write-Log 'PRODUCTION_APPLY_READY=NO'
Write-Log ('FINISHED=' + (Get-Date -Format 'yyyy-MM-ddTHH:mm:ss'))
Write-Output ('AUDIT_STATUS=' + $st.Status)
Write-Output ('SSH_EXIT=' + $st.SshExit)
Write-Output ('OUTPUT=' + $OutLog)
Write-Output 'PRODUCTION_APPLY_READY=NO'
exit $st.WrapperExit
